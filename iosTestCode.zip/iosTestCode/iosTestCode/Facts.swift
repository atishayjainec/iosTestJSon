//
//  Facts.swift
//  iosTestCode
//
//  Created by atishay nayak on 2/4/20.
//  Copyright © 2020 atishay nayak. All rights reserved.
//

import UIKit

class factTitle:Codable{
    let title:String
    let  rows:[Facts]
    init(title:String,  factDetails:[Facts]) {
        self.rows = factDetails
        self.title = title
    }
    
}

class Facts:Codable {
    
    let name :String
    let description:String
    let imageHref : String
    
    init(name:String,description:String,imageHref:String) {
        self.name = name
        self.description = description
        self.imageHref = imageHref
    }
    

}
