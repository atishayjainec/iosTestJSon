//
//  ViewController.swift
//  iosTestCode
//
//  Created by atishay nayak on 2/4/20.
//  Copyright © 2020 atishay nayak. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource {
    final let url = URL(string:"https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json")
    @IBOutlet var tableView:UITableView!
    private  var factsArray = [Facts]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        downloadJson()
        tableView.tableFooterView = UIView()
        // Do any additional setup after loading the view.
    }
    
    func downloadJson(){
        guard let downloadURL = url else {
            return
        }
        URLSession.shared.dataTask(with: downloadURL) { (data, urlResponse, error) in
            guard let data = data, error == nil, urlResponse != nil else
            {
                return
                
            }
            do{
                let decoder = JSONDecoder()
                let facts = try decoder.decode(factTitle.self, from: data)
                print(facts)
                self.factsArray = facts.rows
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("someting Wrong")
                
            }
            
            
        }.resume()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return factsArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        guard  let cell = tableView.dequeueReusableCell(withIdentifier: "customCell") as? customCell else
        {return UITableViewCell() }
        cell.titleLbl.text = factsArray[indexPath.row].name
        cell.descLbl.text = factsArray [indexPath.row].description
        if let imageURL = URL(string: factsArray[indexPath.row].imageHref){
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data{
                    let image = UIImage(data:data)
                    DispatchQueue.main.async {
                        cell.imgView.image = image
                    }
                }
            }
            
        }
        
        return cell
        
    }
    
    
}

