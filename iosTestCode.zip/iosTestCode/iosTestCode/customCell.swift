//
//  customCell.swift
//  iosTestCode
//
//  Created by atishay nayak on 2/4/20.
//  Copyright © 2020 atishay nayak. All rights reserved.
//

import UIKit

class customCell: UITableViewCell {
    @IBOutlet var titleLbl:UILabel!
    @IBOutlet var descLbl:UILabel!
    @IBOutlet var imgView:UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
